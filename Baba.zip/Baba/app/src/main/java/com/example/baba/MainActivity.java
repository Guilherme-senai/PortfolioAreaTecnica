package com.example.baba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.ktx.Firebase;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
    }
    public void Entrar (View patolino ){
        Intent m = new Intent(this, Logar.class);
        startActivity(m);

    }

    
    public void cadastra(View patolino ){
        Intent m = new Intent(this, Cadastra.class);
        startActivity(m);
    }
}