package com.example.baba;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorUsuario extends RecyclerView.Adapter<AdaptadorUsuario.MyViewHolder> {
    Context context;
    ArrayList<Usuario> list;

    public AdaptadorUsuario(Context context, ArrayList<Usuario> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public AdaptadorUsuario.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout, parent,false);
        return new AdaptadorUsuario.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorUsuario.MyViewHolder holder, int position) {
        Usuario u = list.get(position);
        holder.login.setText(u.getLogin());
        holder.idade.setText(u.getIdade());
        holder.turno.setText(u.getTurno());
        holder.sexo.setText(u.getSexo());
        holder.valor.setText(u.getValor());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView login, idade, turno, sexo, valor;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            login = itemView.findViewById(R.id.tLogin);
            idade = itemView.findViewById(R.id.tIdade);
            turno = itemView.findViewById(R.id.tTurno);
            sexo = itemView.findViewById(R.id.tSexo);
            valor = itemView.findViewById(R.id.tValor);
        }
    }
}
