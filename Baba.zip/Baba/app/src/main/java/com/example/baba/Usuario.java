package com.example.baba;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Usuario {
    public String login;
    public String senha;
    public String idade;
    public String turno;
    public String sexo;
    public String valor;

    public Usuario(String login, String senha,String idade, String turno, String sexo, String valor) {
        this.login = login;
        this.senha = senha;
        this.idade = idade;
        this.turno = turno;
        this.valor = valor;
        this.sexo = sexo;
    }

    public Usuario() {
    }

    public void salvar_Bd (){
        DatabaseReference r = FirebaseDatabase.getInstance().getReference();
        r.child("Usuario").child(login).setValue(this);


    }

    public String getLogin() {

        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdade() { return idade; }

    public void setIdade(String idade) { this.idade = idade; }

    public String getValor() { return valor; }

    public void setValor(String valor) { this.valor = valor; }


}

