package com.example.baba;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Logar extends AppCompatActivity {
    EditText login , senha;
    Usuario u = new Usuario();
    boolean aux = false;
    boolean dpd = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logar);
        getSupportActionBar().hide();
        login = findViewById(R.id.login1);
        senha = findViewById(R.id.senha1);
    }
    public void botaoo_entrar(View v){
        dpd = false;
        entrar();
    }

    public void entrar(){

        if(!dpd){
            verifica_usu();
        }else if(dpd){
            //Toast.makeText(this,"Logado!",Toast.LENGTH_SHORT).show();
            mudaTela();
        }

    }
    public void mudaTela(){
        Intent intent = new Intent(this, Lista.class);
        startActivity(intent);
    }
    public void pint(String mensagem){
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();

    }
    public void verifica_usu(){
        DatabaseReference r = FirebaseDatabase.getInstance().getReference().child("Usuario");
        r.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String l = login.getText().toString();
                String s = senha.getText().toString();
                for(DataSnapshot Usuario: snapshot.getChildren()){
                    if(Usuario.getValue(Usuario.class).getLogin().equals(l)
                            && Usuario.getValue(Usuario.class).getSenha().equals(s)){
                        aux = true;
                        dpd=true;

                        //pint("Usuario Já Existe");
                        entrar();
                        break;


                    }
                }
                if(aux == false){
                    pint("Usuario Nao Existe");


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
