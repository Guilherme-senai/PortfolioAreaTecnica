package com.example.baba;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Lista extends AppCompatActivity {
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        getSupportActionBar().hide();
        rv = findViewById(R.id.rv);
        baixaLista();

    }

    public void baixaLista(){
        DatabaseReference r = FirebaseDatabase.getInstance().getReference().child("Usuario");
        r.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Usuario> lista = new ArrayList<>();
                int pos = 0;
                for (DataSnapshot dn : snapshot.getChildren()) {
                    lista.add(dn.getValue(Usuario.class));
                    System.out.println(lista.get(pos).getLogin());
                    pos ++;
                }
                AdaptadorUsuario adaptador = new AdaptadorUsuario(Lista.this, lista);
                rv.setHasFixedSize(true);
                rv.setLayoutManager(new LinearLayoutManager(Lista.this));
                rv.setAdapter(adaptador);
                adaptador.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Lista.this, "Erro ao realizar o download", Toast.LENGTH_SHORT).show();
            }
        });
        //Toast.makeText(this, lista.get(0).getLogin(), Toast.LENGTH_SHORT).show();
    }
}